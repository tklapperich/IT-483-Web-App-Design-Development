﻿using System;

public class Lab02
{
	public Class1()
	{
		float pres = 40.00;
		float nonpres = 25.00;
		float anti = 12.50;
		float brown = 9.99;
		float total = 0.00;

		Console.WriteLine("What kind of glasses would you like:\n1 -> prescription, 2 -> non-prescription");
		glasses_type = Console.ReadLine();
		if (glasses_type == 1)
        {
			total += pres;
			Console.WriteLine("What kind of coating would you like:\n1 -> anti-glare, 2 -> brown tint");
			tint = Console.ReadLine();
			if (tint == 1)
            {
				total += anti;
				Console.WriteLine("Your total cost is " + total);
            }
			else if (tint == 2)
            {
				total += brown;
				Console.WriteLine("Your total cost is " + total);
            }
        }
		else if (glasses_type == 2)
        {
			total += nonpres;
			Console.WriteLine("What kind of coating would you like:\n1 -> anti-glare, 2 -> brown tint, 3 -> none");
			tint = Console.ReadLine();
			if (tint == 1)
            {
				total += anti;
				Console.WriteLine("Your total cost is " + total);
			}
			else if (tint == 2)
			{
				total += brown;
				Console.WriteLine("Your total cost is " + total);
			}
			else if (tint == 3)
            {
				Console.WriteLine("Your total cost is " +total);
            }
		}
	}
}
