using System;

namespace LabD03
{
	class Program
	{
		static void Main(string[] args)
		{
			double curBal = 45.32;

			double amount;
			Console.Write("Please enter a amount to update account by $");
			amount = Console.Read();
			Console.Write("\n");
			double reverse = curBal * -1;
			if (amount < (reverse * -1))
			{
				Console.Write("Amount cannot be withdrawn\n");
				Environment.Exit(0);
			}

			Console.Write("Customer's balance (before transaction) = $" + curBal + "\n");
			Console.Write("Requested update amount = $" + amount + "\n");

			double actAmount;
			actAmount = Transaction(curBal, amount);

			curBal += actAmount;

			Console.Write("Actual update amount = $" + actAmount + "\n");
			Console.Write("Customer's balance (after transaction) = $" + curBal + "\n");

			Console.Write("\nThank you and good-bye!\n");
		}

		static double Transaction(double bal, double amount)
		{
			double final;
			if (amount > 0)
			{
				return amount;
			}
			else
			{
				if (amount > bal)
				{
					final = 0.0;
					return final;
				}
				else
				{
					final = bal - amount;
					return final;
				}
			}
		}
	}
}
