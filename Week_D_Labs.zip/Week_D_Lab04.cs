using System;

namespace Lab04
{
    class Lab04
    {
        static void Main(string[] args)
        {
            int a = 1, b = 3, c = 5;
            double x = 2.2, y = 4.4, z = 6.6, ans;

            ans = Average(a, b);
            Console.Write("\naverage(a, b) = " + ans);

            ans = Average(a, b, c);
            Console.Write("\naverage(a, b, c) = " + ans);

            ans = Average(x, y);
            Console.Write("\naverage(x, y) = " + ans);

            ans = Average(x, y, z);
            Console.Write("\naverage(x, y, z) = " + ans);
        }

        static double Average(int n1, int n2)
        {
            return (n1 + n2) / 2.0;
        }

        static double Average(int n1, int n2, int n3)
        {
            return (n1 + n2 + n3) / 3.0;
        }

        static double Average(double n1, double n2)
        {
            return (n1 + n2) / 2.0;
        }

        static double Average(double n1, double n2, double n3)
        {
            return (n1 + n2 + n3) / 3.0;
        }
    }
}

// 1. We don't need the int parameter unless we want to see the average as an integer. The language will assign zeros for the decimal places.

// 2. You do need the three parameter version, otherwise the order of operations for math is no longer correct.

// 3. That average should be legal, using the fourth Average method.
